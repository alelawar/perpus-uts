<x-layout>
    {{-- {{ form dan capthca disini }} --}}
</x-layout>